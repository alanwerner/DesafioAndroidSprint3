package com.example.catalagofilmes

import android.content.Context

class ListaFilmesAdapter(
    private val context: Context,

) {

}