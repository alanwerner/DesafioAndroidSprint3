package com.example.catalagofilmes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView

class ListaFilmesActivity : AppCompatActivity() {

    private val adapter = ListaFilmesAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_filmes)
        val recyclerView = findViewById<RecyclerView>(R.id.activity_lista_filmes_recyclerView)
        recyclerView.adapter = adapter
    }
}